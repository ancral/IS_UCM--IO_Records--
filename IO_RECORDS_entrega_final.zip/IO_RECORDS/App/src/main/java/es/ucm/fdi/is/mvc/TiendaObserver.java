package es.ucm.fdi.is.mvc;

public interface TiendaObserver {
	
	public void notify(Notificacion notificacion);

}
