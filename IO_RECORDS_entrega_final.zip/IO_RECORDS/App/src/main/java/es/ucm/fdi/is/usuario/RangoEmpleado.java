package es.ucm.fdi.is.usuario;

public enum RangoEmpleado {
	
	DIRECTIVO,
	JEFE_DE_SECCION,
	PROFESIONAL,
	TECNICO,
	ADMINISTRATIVO;	

}
