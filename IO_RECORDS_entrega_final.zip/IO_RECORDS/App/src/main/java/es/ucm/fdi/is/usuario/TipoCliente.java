package es.ucm.fdi.is.usuario;

public enum TipoCliente {
	
	FRECUENTE,
	HABITUAL,
	OCASIONAL,
	NUEVO;

}
