package com.github.plushaze.traynotification.notification;

public interface Notification {

	String getURLResource();

	String getPaintHex();

}
