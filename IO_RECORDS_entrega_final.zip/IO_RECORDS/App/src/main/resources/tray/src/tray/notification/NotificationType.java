package tray.notification;

public enum NotificationType {
    INFORMATION,
    NOTICE,
    SUCCESS,
    WARNING,
    ERROR,
    CUSTOM
}
